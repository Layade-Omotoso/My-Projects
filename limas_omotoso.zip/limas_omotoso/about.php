
<?php include('header.php'); ?>
<?php include('navbar_about.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">	
			<?php include('head.php'); ?>
				
				<div class="text_content">
					
					<table width="450" style="margin: 0pt auto;">
	
	<thead><tr><th colspan="3" style="text-align: center;"><h3>LIBRARY HOURS</h3></th></tr></thead>
	<tbody>
	<tr>
	<td colspan="3"></td>
	</tr>
	<tr>
	<td>Monday to Friday</td>
	<td>8:00 a.m. to 12:30 a.m.</td>
	</tr>
	<tr>
	<td>Saturday and Sunday</td>
	<td>8:00 a.m. to 8:00 p.m.</td>
	</tr>
	</tbody>
	</table>
	
	<table class="staff" >
	<thead><tr><th colspan="3"  style="text-align: center;"><h3>LIBRARY STAFF</h3></th></tr></thead>
	<tbody>
	<tr>
	<td colspan="3"></td>
	</tr>
	<tr>
	<td>Mr. Omotoso Layade<br />Chief Librarian </td>
	</tr>
	
	</tbody>
	</table>
					
					</div>
					</div>
			
		</div>
    </div>
<?php include('footer.php') ?>
