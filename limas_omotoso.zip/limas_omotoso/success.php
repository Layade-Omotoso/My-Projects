<?php include('header.php'); ?>
<?php include('navbar.php'); ?>

    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head.php'); ?>
		
				<div class="span12">
	<center>
				<h2>You are Successfully Registered. You can now login your account.</h2>
				<h2>Thank You</h2>
					
								
									</center>
				</div>
			
				
			</div>
		</div>
    </div>
<?php include('footer.php') ?>