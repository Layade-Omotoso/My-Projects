			<div class="life-side-bar">
			<div class="hero-container">                  
			
					
			</div>
			
			
		
					
					
							<ul class="nav nav-tabs nav-stacked">
						<li class="">
						<a   href="#">&nbsp;    Contact US</a>
						</li>
					</ul>
<strong>Address</strong>
<p>26, Niger West, Orita-Challenge, Ibadan, Oyo State </p>
<p>Telephone No. :</p>
<p>07054105255</p>



			
			</div>
			
	