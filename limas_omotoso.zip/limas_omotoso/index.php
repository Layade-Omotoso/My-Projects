<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">
				<?php include('head.php'); ?>
			</div>
		<table width="100%">
			<tr>
				<th style='text-align:left; font-size:15pt; padding:20px' colspan="6"> Popular Books </th>
			</tr>
			<tr>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/1.png" alt="book1"> </a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/2.png" alt="book2"> </a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/3.png" alt="book3"> </a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/4.png" alt="book4"> </a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/5.png" alt="book5"> </a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/6.png" alt="book6"> </a>	</td>
			

			</tr>
			<tr>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/7.png" alt="book7"> 	</a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/8.png" alt="book8"> 	</a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/9.png" alt="book9"> 	</a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/10.png" alt="book10"> 	</a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/11.png" alt="book11"> 	</a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/12.png" alt="book12"> 	</a>	</td>
			

			</tr>
			<tr>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/13.png" alt="book13"> 	</a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/14.png" alt="book14"> 	</a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/15.png" alt="book15"> 	</a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/16.png" alt="book16"> 	</a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/17.png" alt="book17"> 	</a>	</td>
		<td ><a href="librarian/"><img class="bookthumbnail" src="images/18.png" alt="book18"> 	</a>	</td>
			

			</tr>

		</table>

			
				</div>
			
			</div>
		</div>
    </div>
	
<?php include('footer.php') ?>	
