<?php
$file = fopen('nhbabcock.lam','r');

$mysize = filesize('nhbabcock.lam');
echo fread($file,$mysize);
fclose($file);