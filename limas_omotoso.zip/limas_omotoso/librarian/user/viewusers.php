<?php include '../dbcon.php';
$user_query = mysqli_query($con, "SELECT * FROM users");
