<?php
include('../dbcon.php');

$id = $_GET['id'];
$query = "delete from users where user_id = '$id'";
mysqli_query($con, $query);
header('location:users.php');
