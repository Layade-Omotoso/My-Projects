<?php
include('../dbcon.php');
$id = $_GET['id'];
mysqli_query($con, "UPDATE book SET `status` = 'Archive' WHERE book_id = '$id'") or die(mysqli_error($con));
header('location:books.php');