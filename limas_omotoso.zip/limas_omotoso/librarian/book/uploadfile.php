<?php 
$dir = "uploads/";
$targetfile = $dir.basename($_FILES["filetoupload"]["name"]);
if(move_uploaded_file($_FILES["filetoupload"]["tmp_name"],$targetfile)){
    echo "Successful";
}
else{
    echo "Not successful";
}
