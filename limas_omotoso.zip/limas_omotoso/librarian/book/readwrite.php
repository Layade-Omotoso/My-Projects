<?php 
$file = fopen('forus.txt','w');
;
if(!fwrite($file,"Good morning all<br> It is going well")){
    echo "Not written";
}

$file2 = fopen('forus.txt','r');
$size = filesize('forus.txt');
$toread = fread($file2,$size);
echo $toread;
fclose($file);
