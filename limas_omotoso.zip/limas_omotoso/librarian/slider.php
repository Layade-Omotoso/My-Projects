<?php 

echo "<div> You are welcome, ".$_SESSION['id']."! </div>";
