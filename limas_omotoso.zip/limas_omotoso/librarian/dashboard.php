<?php session_destroy();?>
<?php session_start();?>
<?php include('dbcon.php');?>
<?php include('header.php'); ?>
<?php include('navbar_dashboard.php'); ?>

<?php echo "<div style='padding: 20px; float:right'> You are welcome,<b> ".$_SESSION['id']."! </b></div>"; ?>
<div style="width:100%; margin-top:-10px">

<?php 
    $query = "SELECT * FROM book";
    $result = mysqli_query($con, $query)or die(mysqli_error($con));
    $num_row = mysqli_num_rows($result);
    echo "<div style='margin:10px; border-radius:10px; opacity:0.8; position:absolute; z-index:1; width:25%; background-color:#1b0d39; color:white; padding:10px'>";
    echo "<div class='bookasset' style='font-size:20px'><a href='book/books.php'> TOTAL BOOKS <span class='bkassetval' class='bkassetval'>". $num_row."</span></a></div>";

    $query = "SELECT * FROM book WHERE `status` = 'New' ";
    $result = mysqli_query($con, $query)or die(mysqli_error($con));
    $num_row = mysqli_num_rows($result);
    echo "<div class='bookasset'> <a href='book/new_books.php'> NEW BOOKS <span class='bkassetval'>". $num_row."</span></a></div>";
 
    
    $query = "SELECT * FROM book WHERE `status` = 'Old' ";
    $result = mysqli_query($con, $query)or die(mysqli_error($con));
    $num_row = mysqli_num_rows($result);
    echo "<div class='bookasset'><a href='book/old_books.php'>OLD BOOKS<span class='bkassetval'>". $num_row."</span></a></div>";

    $query = "SELECT * FROM borrowdetails WHERE `borrow_status` = 'pending'";
    $result = mysqli_query($con, $query)or die(mysqli_error($con));
    $num_row = mysqli_num_rows($result);
    echo "<div class='bookasset'> BORROWED BOOKS <span class='bkassetval'>". $num_row."</span></div>";
 
    $query = "SELECT * FROM borrowdetails WHERE `borrow_status` = 'returned'";
    $result = mysqli_query($con, $query)or die(mysqli_error($con));
    $num_row = mysqli_num_rows($result);
    echo "<div class='bookasset'> RETURNED BOOKS <span class='bkassetval'>". $num_row."</span></div>";
 

    $query = "SELECT * FROM book WHERE `status` = 'Lost' ";
    $result = mysqli_query($con, $query)or die(mysqli_error($con));
    $num_row = mysqli_num_rows($result);
    echo "<div class='bookasset'> LOST BOOKS <span class='bkassetval'>". $num_row."</span></div>";

    $query = "SELECT * FROM book WHERE `status` = 'Damaged' ";
    $result = mysqli_query($con, $query)or die(mysqli_error($con));
    $num_row = mysqli_num_rows($result);
    echo "<div class='bookasset'> DAMAGED BOOKS<span class='bkassetval'>". $num_row."</span></div>";

    $query = "SELECT * FROM book WHERE `status` = 'Archive' ";
    $result = mysqli_query($con, $query)or die(mysqli_error($con));
    $num_row = mysqli_num_rows($result);
    echo "<div class='bookasset'> Total Archive <span class='bkassetval'>". $num_row."</span></div>";
    echo "</div>";

    
    ?>
     <div style="position:absolute; z-index:0; width:100%">
        <img src="../LMS/EB88.jpg" style="width:100%">
    </div>
<?php include('footer.php') ?>
