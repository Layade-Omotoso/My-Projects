<?php 
$dir = "uploads/";
$targetfile = $dir.basename($_FILES["file"]["name"]);
if(move_uploaded_file($_FILES["file"]["tmp_name"],$targetfile)){
    echo "Successful";
}
else{
    echo "Not successful";
}
