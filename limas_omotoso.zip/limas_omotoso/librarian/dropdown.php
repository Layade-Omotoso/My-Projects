					<li>		
					<a href="../borrow.php"  data-toggle="dropdown"> Transaction</a>
					<ul class="dropdown-menu">
					<li><a href="book/borrow.php">&nbsp;Borrow</a></li>
					<li><a href="book/return.php">&nbsp;View Returned Books</a></li>
					<li><a href="book/view_borrow.php">&nbsp;View Borrowed Books</a></li>
					</ul>
					</li>