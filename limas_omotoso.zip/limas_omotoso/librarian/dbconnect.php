<?php
function connectToDb(){
    $con = mysqli_connect("localhost","root","");
    if(!$con){
        echo "Not Connected";
    }
}