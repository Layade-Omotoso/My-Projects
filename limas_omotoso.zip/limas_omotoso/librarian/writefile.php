<?php
$file = fopen('nhbabcock.lam','a');

$content = "A town hall is different from labalu<br>";

if(fwrite($file,$content)){
    echo "Successful";
}
else {
    echo "Not Successful";

}

fclose($file);