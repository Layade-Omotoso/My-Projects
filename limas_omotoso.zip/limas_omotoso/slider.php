		
    	<div style="overflow:hidden; width:960px; margin:0 auto;"> 
                <div class="pix_diapo">

                    <div data-thumb="LMS/EB11.jpg">
                        <img src="LMS/EB11.jpg" width="100%">
                    </div>
                    
                    <div data-thumb="LMS/EB22.jpg">
                        <img src="LMS/EB22.jpg" width="100%"> 
                    </div>
                    
                    <div data-thumb="LMS/EB33.jpg">
                        <img src="LMS/EB33.jpg" width="100%">
                    </div>
					
					<div data-thumb="LMS/EB44.jpg">
                        <img src="LMS/EB44.jpg" width="100%"> 
                    
                    </div>
					<div data-thumb="LMS/EB55.jpg">
                        <img src="LMS/EB55.jpg" width="100%"> 
                    
                    </div>
					<div data-thumb="LMS/EB66.jpg">
                        <img src="LMS/EB66.jpg" width="100%"> 
                    
                    </div>
					<div data-thumb="LMS/EB77.jpg">
                        <img src="LMS/EB77.jpg" width="100%"> 
                    </div>
					
					<div data-thumb="LMS/EB88.jpg">
                        <img src="LMS/EB88.jpg" width="100%"> 
                    </div>
					
					<div data-thumb="LMS/EB99.jpg">
                        <img src="LMS/EB99.jpg" width="100%"> 
                    </div>
               </div><!-- #pix_diapo -->
                
        </div>
    
    
    </section> 