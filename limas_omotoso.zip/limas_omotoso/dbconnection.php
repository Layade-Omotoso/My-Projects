<?php session_start();?>
<?php
$con = new mysqli("localhost","root","","softdev");
if(!$con){
    echo "Not connected";
}
$username = $_POST['user'];
$password = $_POST['psw'];
$fullname = $_POST['fname'];
$query = "INSERT INTO studentrecord (`username`,`password`,`fullnames`) VALUES('$username','$password','$fullname')";
mysqli_query($con, $query)or die(mysqli_error($con));
$_SESSION['status'] = "Account created successfully";
$_SESSION['fname'] = $fullname;
header("Location:../tosho.php");