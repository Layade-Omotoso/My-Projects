<?php
    $con = new mysqli("localhost","root","","eb_lms");
